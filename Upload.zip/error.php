<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page Not Found | கற்பக விநாயகர் தேவஸ்தானம்</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Anek+Tamil:wght@100..800&family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/Assets/CSS/main.css">
    <style>
        .error-page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: var(--bg);
            padding: 24px;
            text-align: center;
        }

        .error-code {
            font-size: clamp(5rem, 20vw, 10rem);
            font-weight: 900;
            color: var(--primary);
            opacity: 0.15;
            line-height: 1;
            font-family: var(--font-english);
        }

        .error-icon {
            font-size: 4rem;
            margin-bottom: 16px;
        }

        .error-title {
            font-family: var(--font-tamil);
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 8px;
        }

        .error-sub {
            color: var(--text-sub);
            font-size: 1rem;
            margin-bottom: 32px;
            font-family: var(--font-english);
        }

        .error-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 28px;
            background: var(--primary);
            color: #fff;
            border-radius: var(--radius-sm);
            font-weight: 700;
            text-decoration: none;
            transition: var(--transition);
            font-family: var(--font-english);
        }

        .error-back:hover {
            background: var(--primary-light);
        }
    </style>
    <script>
        setTimeout(() => {
            window.location.href = '/';
        }, 7000);
    </script>
</head>

<body>
    <div class="error-page">
        <div class="error-code">404</div>
        <div class="error-icon">🙏</div>
        <h1 class="error-title">பக்கம் கண்டுபிடிக்கவில்லை</h1>
        <p class="error-sub">The page you are looking for could not be found.<br>You will be redirected to the home page shortly.</p>
        <a href="/" class="error-back">
            <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 -960 960 960" width="18px" fill="currentColor">
                <path d="M240-200h133.85v-237.69h172.3V-200H680v-360L480-714.62 240-560v360Zm-60 60v-450l300-225.77L780-590v450H486.15v-237.69h-12.3V-140H180Zm300-330.38Z" />
            </svg>
            Go Home
        </a>
    </div>
</body>

</html>