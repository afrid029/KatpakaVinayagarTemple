<?php SESSION_START() ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gallery | கற்பக விநாயகர் தேவஸ்தானம்</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Anek+Tamil:wght@100..800&family=Mukta+Malar:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/Assets/CSS/main.css">
    <link rel="stylesheet" href="/Assets/CSS/index-page.css">
</head>

<body>

    <!-- NAV -->
    <nav class="site-nav">
        <div class="nav-bg"></div>
        <div class="nav-brand">
            <button class="nav-hamburger" id="navHamburger" aria-label="Toggle menu" onclick="toggleDrawer()">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor">
                    <path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z" />
                </svg>
            </button>
            <div class="nav-brand-center">
                <img src="/Assets/Images/R1.PNG" class="nav-logo" alt="Temple Logo">
                <div class="nav-title">
                    <span class="nav-title-tamil">அருள்மிகு கற்பக விநாயகர் தேவஸ்தானம் - பிரம்றன்</span>
                    <span class="nav-title-english">Arulmigu Katpaga Vinayagar Hindu Temple - Brampton</span>
                </div>
            </div>
            <?php if (isset($_COOKIE['user'])): ?>
                <a href="/dashboard" class="nav-action">
                    <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 -960 960 960" width="18px" fill="currentColor">
                        <path d="M192-192v-96l72-72v168h-72Zm126 0v-222l66-66 6 6v282h-72Zm126 0v-228l72 72v156h-72Zm126 0v-186l72-72v258h-72Zm126 0v-312l72-72v384h-72ZM192-378v-102l192-192 144 144 240-240v102L528-426 384-570 192-378Z" />
                    </svg>
                    Dashboard</a>
                <a href="/logout" class="nav-action">
                    <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 -960 960 960" width="18px" fill="currentColor">
                        <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z" />
                    </svg>
                    Logout</a>
            <?php else: ?>
                <button onclick="openLogin()" class="nav-action">Login</button>
            <?php endif; ?>
        </div>
        <div class="nav-links-bar">
            <a href="/" class="nav-link">Home</a>
            <a href="/calendar" class="nav-link">Calendar</a>
            <a href="/notice" class="nav-link">Notice</a>
            <a href="/gallery" class="nav-link active">Gallery</a>
            <a class="nav-link" onclick="gotoAbout()">About</a>
        </div>
    </nav>

    <!-- NAV DRAWER (mobile) -->
    <div class="nav-drawer" id="navDrawer">
        <button class="nav-drawer-close" onclick="closeDrawer()" aria-label="Close">&#x2715;</button>
        <a href="/" class="nav-drawer-link">Home</a>
        <a href="/calendar" class="nav-drawer-link">Calendar</a>
        <a href="/notice" class="nav-drawer-link">Notice</a>
        <a href="/gallery" class="nav-drawer-link">Gallery</a>
        <a class="nav-drawer-link" onclick="gotoAbout();closeDrawer();">About</a>
        <?php if (isset($_COOKIE['user'])): ?>
            <a href="/dashboard" class="nav-drawer-link">Dashboard</a>
            <a href="/logout" class="nav-drawer-link">Logout</a>
        <?php else: ?>
            <button onclick="openLogin();closeDrawer();" class="nav-drawer-link">Login</button>
        <?php endif; ?>
    </div>

    <!-- Gallery Section -->
    <section class="section section-cream" style="min-height:70vh;">
        <div class="section-heading flex flex-col">
            <h2>Gallery</h2>
            <p>Explore our collection of albums from temple events and celebrations</p>
        </div>
        <div id="gallery-content" class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"></div>
        <div id="table-pagi" class="pagination" style="margin-top:24px;justify-content:center;"></div>
    </section>

    <!-- About -->
    <?php include('Components/aboutus.php') ?>

    <!-- Login Modal -->
    <?php include('Components/loginModel.php') ?>

    <!-- Album Lightbox -->
    <div id="album-model" class="model-overlay2" style="display:none;">
        <div class="model-content2">
            <button onclick="closeAlbumView()" class="close-btn2">&#x2715; Close</button>
            <button class="btn backbtn" style="display:none;">
                <span class="material-symbols-outlined">arrow_circle_left</span>
            </button>
            <button class="btn rightBtn">
                <span class="material-symbols-outlined">arrow_circle_right</span>
            </button>
            <div id="bgimg" class="bgimg"></div>
        </div>
    </div>

    <!-- Notice Model -->
    <div id="notice-model" class="model-overlay2" style="display:none;">
        <div class="model-content2">
            <button onclick="closeNoticeModel()" class="close-btn2">&#x2715; Close</button>
            <button id="leftNot" class="btn backbtn" style="display:none;">
                <span class="material-symbols-outlined">arrow_circle_left</span>
            </button>
            <button id="rightNot" class="btn rightBtn">
                <span class="material-symbols-outlined">arrow_circle_right</span>
            </button>
            <div id="bgimg3" class="bgimg"></div>
        </div>
    </div>

    <!-- Image Viewer (notice full view) -->
    <div id="image-viewer" class="modal-overlay" style="display:none;background:rgba(0,0,0,0.85);">
        <div style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
            <button onclick="closeImageViewer()" style="position:fixed;top:14px;right:14px;width:36px;height:36px;border-radius:50%;background:#000;color:#fff;border:none;font-size:1rem;cursor:pointer;z-index:10;display:flex;align-items:center;justify-content:center;">&#x2715;</button>
            <img id="frontImg" src="" alt="Notice" style="max-width:95vw;max-height:92vh;object-fit:contain;border-radius:8px;">
        </div>
    </div>

</body>

</html>

<script>
    /* ─── Login modal ─── */
    function openLogin() {
        document.getElementById('login-model').style.display = 'flex';
    }

    function closeLoginViewer() {
        document.getElementById('login-model').style.display = 'none';
    }

    /* ─── Drawer ─── */
    function toggleDrawer() {
        document.getElementById('navDrawer').classList.toggle('is-open');
    }

    function closeDrawer() {
        document.getElementById('navDrawer').classList.remove('is-open');
    }

    /* ─── About scroll ─── */
    function gotoAbout(val) {
        const element = document.querySelector('.about-section');
        if (!element) return;
        const rect = element.getBoundingClientRect();
        window.scrollTo({
            top: window.scrollY + rect.top - (val ? 200 : 0),
            behavior: 'smooth'
        });
    }

    /* ─── Album lightbox ─── */
    let albumImages = [];
    let currentIndex = 0;
    let next = 0;
    const backBtn = document.querySelector('.backbtn');
    const rightBtn = document.querySelector('.rightBtn');
    const posterImg = document.getElementById('bgimg');

    backBtn.addEventListener('click', goBack);
    rightBtn.addEventListener('click', goNext);

    function closeAlbumView() {
        document.getElementById('album-model').style.display = 'none';
        currentIndex = 0;
        next = 0;
        backBtn.style.display = 'none';
        rightBtn.style.display = 'block';
    }

    function openAlbum(data) {
        albumImages = [];
        data.split(' ,').forEach(el => {
            const trimmed = el.trim();
            if (trimmed) albumImages.push(trimmed);
        });
        document.getElementById('bgimg').style.backgroundImage = `url('${albumImages[0]}')`;
        document.getElementById('album-model').style.display = 'block';
    }

    function goBack() {
        next = -1;
        currentIndex -= 1;
        updateAlbum();
    }

    function goNext() {
        next = 1;
        currentIndex += 1;
        updateAlbum();
    }

    function updateAlbum() {
        if (currentIndex == 0) {
            backBtn.style.display = 'none';
            rightBtn.style.display = 'block';
        } else if (currentIndex == albumImages.length - 1) {
            rightBtn.style.display = 'none';
            backBtn.style.display = 'block';
        } else {
            backBtn.style.display = 'block';
            rightBtn.style.display = 'block';
        }
        posterImg.style.backgroundImage = `url('${albumImages[currentIndex]}')`;
        if (next == -1) {
            posterImg.classList.add('moveRightOff');
            setTimeout(() => {
                posterImg.classList.remove('moveRightOff');
                posterImg.classList.add('moveRightIn');
            }, 300);
            setTimeout(() => {
                posterImg.classList.remove('moveRightIn');
            }, 600);
        } else {
            posterImg.classList.add('moveleftOff');
            setTimeout(() => {
                posterImg.classList.remove('moveleftOff');
                posterImg.classList.add('moveLeftIn');
            }, 300);
            setTimeout(() => {
                posterImg.classList.remove('moveLeftIn');
            }, 600);
        }
    }

    /* ─── Notice model ─── */
    let notice = [];
    let noticeIndex = 0;
    const right = document.getElementById('rightNot');
    const left = document.getElementById('leftNot');
    const noticeImg = document.getElementById('bgimg3');
    left.addEventListener('click', updateNotice);
    right.addEventListener('click', updateNotice);

    function openNoticeModel() {
        document.getElementById('notice-model').style.display = 'block';
        noticeImg.style.backgroundImage = `url('${notice[noticeIndex]}')`;
        noticeIndex = 1;
    }

    function closeNoticeModel() {
        document.getElementById('notice-model').style.display = 'none';
        noticeIndex = 0;
    }

    function updateNotice() {
        if (noticeIndex == 1) {
            noticeImg.classList.add('moveRightOff');
            noticeImg.style.backgroundImage = `url('${notice[noticeIndex]}')`;
            right.style.display = 'none';
            left.style.display = 'block';
            setTimeout(() => {
                noticeImg.classList.remove('moveRightOff');
                noticeImg.classList.add('moveRightIn');
            }, 500);
            setTimeout(() => {
                noticeImg.classList.remove('moveRightIn');
            }, 1000);
            noticeIndex = 0;
        } else {
            noticeImg.style.backgroundImage = `url('${notice[noticeIndex]}')`;
            right.style.display = 'block';
            left.style.display = 'none';
            noticeImg.classList.add('moveleftOff');
            setTimeout(() => {
                noticeImg.classList.remove('moveleftOff');
                noticeImg.classList.add('moveLeftIn');
            }, 500);
            setTimeout(() => {
                noticeImg.classList.remove('moveLeftIn');
            }, 1000);
            noticeIndex = 1;
        }
    }

    /* ─── Image viewer ─── */
    document.getElementById('bgimg3').addEventListener('click', e => {
        const path = e.target.style.backgroundImage.slice(5, -2);
        document.getElementById('frontImg').setAttribute('src', path);
        document.getElementById('image-viewer').style.display = 'block';
    });

    function closeImageViewer() {
        document.getElementById('image-viewer').style.display = 'none';
    }

    /* ─── Load data ─── */
    function loadNotice() {
        notice = [];
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '/Controllers/GetNotice.php', true);
        xhr.onload = function() {
            if (xhr.status == 200 && xhr.readyState == 4) {
                var response = JSON.parse(xhr.responseText);
                let tamilN = response.data[0].tamil;
                notice.push(tamilN.split('<?php echo $_SERVER['DOCUMENT_ROOT'] ?>')[1]);
                let englishN = response.data[0].eng;
                notice.push(englishN.split('<?php echo $_SERVER['DOCUMENT_ROOT'] ?>')[1]);
            }
        };
        xhr.send();
    }

    function loadAlbum(page) {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '/Controllers/GetAllAlbum.php?page=' + page, true);
        xhr.onload = function() {
            if (xhr.status == 200 && xhr.readyState == 4) {
                var response = JSON.parse(xhr.responseText);
                document.getElementById('gallery-content').innerHTML = response.html;
                document.getElementById('table-pagi').innerHTML = response.pagination;
            }
        };
        xhr.send();
    }

    window.onload = function() {
        loadAlbum(1)
    };
</script>