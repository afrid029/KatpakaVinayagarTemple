<?php SESSION_START() ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>அருள்மிகு கற்பக விநாயகர் தேவஸ்தானம்</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Anek+Tamil:wght@100..800&family=Mukta+Malar:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/Assets/CSS/main.css">
    <link rel="stylesheet" href="/Assets/CSS/index-page.css">
</head>

<body>

    <!-- NAVIGATION -->
    <nav class="site-nav">
        <div class="nav-bg"></div>
        <div class="nav-brand">
            <button class="nav-hamburger" id="navHamburger" aria-label="Toggle menu" aria-expanded="false">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-brand-center">
                <img src="/Assets/Images/R1.PNG" class="nav-logo" alt="Katpaga Vinayagar Temple Logo">
                <div class="nav-title">
                    <span class="nav-title-tamil">அருள்மிகு கற்பக விநாயகர் தேவஸ்தானம் - பிரம்றன்</span>
                    <span class="nav-title-english">Arulmigu Katpaga Vinayagar Hindu Temple - Brampton</span>
                </div>
            </div>
            <?php if (!isset($_COOKIE['user'])): ?>
                <button class="nav-action" onclick="openLogin()">
                    <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 -960 960 960" width="18px" fill="currentColor">
                        <path d="M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840v106q-106.26 0-180.13 73.87Q226-586.26 226-480q0 106.26 73.87 180.13Q373.74-226 480-226v106Zm160-141.35L565.35-337l90-90H347v-106h308.35l-90-91L640-698.65 858.65-480 640-261.35Z" />
                    </svg>
                    Login
                </button>
            <?php else: ?>
                <a href="/dashboard" class="nav-action" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 -960 960 960" width="18px" fill="currentColor">
                        <path d="M192-192v-96l72-72v168h-72Zm126 0v-222l66-66 6 6v282h-72Zm126 0v-228l72 72v156h-72Zm126 0v-186l72-72v258h-72Zm126 0v-312l72-72v384h-72ZM192-378v-102l192-192 144 144 240-240v102L528-426 384-570 192-378Z" />
                    </svg>
                    Dashboard
                </a>
                <a href="/logout" class="nav-action">
                    <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 -960 960 960" width="18px" fill="currentColor">
                        <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z" />
                    </svg>
                    Logout
                </a>
            <?php endif; ?>
        </div>
        <div class="nav-links-bar">
            <span class="nav-link active">Home</span>
            <a href="/calendar">Calendar</a>
            <a href="/notice">Notice</a>
            <a href="/gallery">Gallery</a>
            <a class="nav-link" onclick="gotoAbout()">About</a>
        </div>
        <div class="nav-drawer" id="navDrawer">
            <span class="nav-drawer-link active">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                    <path d="M240-200h133.85v-237.69h212.3V-200H720v-360L480-740.77 240-560v360Zm-60 60v-450l300-225.77L780-590v450H526.15v-237.69h-92.3V-140H180Zm300-330.38Z" />
                </svg>
                Home
            </span>
            <a href="/calendar">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                    <path d="M200-80q-33 0-56.5-23.5T120-160v-560q0-33 23.5-56.5T200-800h40v-80h80v80h320v-80h80v80h40q33 0 56.5 23.5T840-720v560q0 33-23.5 56.5T760-80H200Zm0-80h560v-400H200v400Z" />
                </svg>
                Calendar
            </a>
            <a href="/notice">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                    <path d="M480-400q17 0 28.5-11.5T520-440v-200q0-17-11.5-28.5T480-680q-17 0-28.5 11.5T440-640v200q0 17 11.5 28.5T480-400Zm0 120q20 0 34-14t14-34q0-20-14-34t-34-14q-20 0-34 14t-14 34q0 20 14 34t34 14Zm0 280q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480 0Z" />
                </svg>
                Notice
            </a>
            <a href="/gallery">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                    <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm40-80h480L570-480 450-320l-90-120-120 160Z" />
                </svg>
                Gallery
            </a>
            <a class="nav-drawer-link" onclick="gotoAbout(); closeDrawer();">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                    <path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-160v-112q0-34 17.5-62.5T224-378q62-31 128.5-46.5T480-440q66 0 132.5 15.5T741-378q29 15 46.5 43.5T805-272v112H160Z" />
                </svg>
                About
            </a>
            <?php if (!isset($_COOKIE['user'])): ?>
                <span class="nav-drawer-link" onclick="openLogin(); closeDrawer();">
                    <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                        <path d="M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840v106q-106.26 0-180.13 73.87Q226-586.26 226-480q0 106.26 73.87 180.13Q373.74-226 480-226v106Zm160-141.35L565.35-337l90-90H347v-106h308.35l-90-91L640-698.65 858.65-480 640-261.35Z" />
                    </svg>
                    Login
                </span>
            <?php else: ?>
                <a href="/dashboard" class="nav-drawer-link">
                    <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                        <path d="M192-192v-96l72-72v168h-72Zm126 0v-222l66-66 6 6v282h-72Zm126 0v-228l72 72v156h-72Zm126 0v-186l72-72v258h-72Zm126 0v-312l72-72v384h-72ZM192-378v-102l192-192 144 144 240-240v102L528-426 384-570 192-378Z" />
                    </svg>
                    Dashboard
                </a>
                <a href="/logout" class="nav-drawer-link">
                    <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#f59e0b">
                        <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z" />
                    </svg>
                    Logout
                </a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- ALERT TOAST -->
    <?php if (isset($_SESSION['fromAction']) && $_SESSION['fromAction'] === true): ?>
        <div class="alert-container" id="alertSecond" style="display:flex;">
            <div class="alert" id="alertContSecond">
                <p><?php echo htmlspecialchars($_SESSION['message']); ?></p>
            </div>
        </div>
        <?php if ($_SESSION['status'] === true): ?>
            <script>
                document.getElementById('alertContSecond').style.backgroundColor = '#1D7524';
            </script>
        <?php else: ?>
            <script>
                document.getElementById('alertContSecond').style.backgroundColor = '#E44C4C';
            </script>
        <?php endif; ?>
        <script>
            setTimeout(() => {
                document.getElementById('alertSecond').style.display = 'none';
            }, 5000);
        </script>
    <?php $_SESSION['fromAction'] = false;
    endif; ?>

    <!-- HERO BANNER -->
    <section class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-inner">
            <img src="/Assets/Images/vin.jpg" class="hero-seal" alt="Vinayagar">
            <p class="hero-text">சகல வித்தைகளும் கைகூடி மகாமேதை எனும் நிலையை எட்டச் செய்பவர் இந்த விநாயகர்</p>
        </div>
    </section>

    <!-- LIVE TV -->
    <section class="section section-cream">
        <div class="section-heading">
            <h3>நேரலை | Live</h3>
        </div>
        <div class="live-container">
            <?php include('Components/LiveTv.php') ?>
        </div>
    </section>

    <!-- UPCOMING EVENTS -->
    <section class="section section-white">
        <div class="section-heading">
            <h3>Upcoming Events</h3>
        </div>
        <div class="events-layout">
            <div id="event-details" class="events-grid events-grid--col"></div>
            <div class="events-side-img">
                <img src="/Assets/Images/vin3.png" alt="Katpaga Vinayagar">
            </div>
        </div>
    </section>

    <!-- GALLERY PREVIEW -->
    <section class="section section-pattern">
        <div class="section-heading" style="position:relative;z-index:1;">
            <h3>Gallery</h3>
            <a href="/gallery">View all &rsaquo;&rsaquo;</a>
        </div>
        <div id="gallery-content" class="gallery-grid gallery-grid--home" style="position:relative;z-index:1;"></div>
    </section>

    <!-- ABOUT -->
    <?php include('Components/aboutus.php') ?>

    <!-- LOGIN MODAL -->
    <?php include('Components/loginModel.php') ?>

    <!-- ALBUM LIGHTBOX -->
    <div id="album-model" class="model-overlay2">
        <div class="model-content2">
            <button onclick="closeAlbumView()" class="close-btn2">&#x2715; Close</button>
            <div class="btn backbtn" aria-label="Previous">
                <span class="material-symbols-outlined">arrow_circle_left</span>
            </div>
            <div class="btn rightBtn" aria-label="Next">
                <span class="material-symbols-outlined">arrow_circle_right</span>
            </div>
            <div id="bgimg" class="bgimg"></div>
        </div>
    </div>

</body>

</html>

<script>
    const navHamburger = document.getElementById('navHamburger');
    const navDrawer = document.getElementById('navDrawer');
    navHamburger.addEventListener('click', () => {
        const open = navDrawer.classList.toggle('is-open');
        navHamburger.classList.toggle('is-open', open);
        navHamburger.setAttribute('aria-expanded', open);
    });

    function closeDrawer() {
        navDrawer.classList.remove('is-open');
        navHamburger.classList.remove('is-open');
        navHamburger.setAttribute('aria-expanded', 'false');
    }

    function gotoAbout(val) {
        closeDrawer();
        const element = document.querySelector('.about-section');
        if (!element) return;
        const rect = element.getBoundingClientRect();
        window.scrollTo({
            top: window.scrollY + rect.top - (val ? 80 : 0),
            behavior: 'smooth'
        });
    }

    function openLogin() {
        closeDrawer();
        document.getElementById('login-model').style.display = 'flex';
    }

    function closeLoginViewer() {
        document.getElementById('login-model').style.display = 'none';
    }
    let albumImages = [],
        currentIndex = 0,
        next = 0;
    const backBtn = document.querySelector('.backbtn');
    const rightBtn = document.querySelector('.rightBtn');
    const posterImg = document.getElementById('bgimg');
    backBtn.addEventListener('click', goBack);
    rightBtn.addEventListener('click', goNext);

    function closeAlbumView() {
        document.getElementById('album-model').style.display = 'none';
        currentIndex = 0;
        next = 0;
        backBtn.style.display = 'none';
        rightBtn.style.display = 'flex';
    }

    function openAlbum(data) {
        albumImages = [];
        data.split(' ,').forEach(el => {
            const trimmed = el.trim();
            if (trimmed) albumImages.push(trimmed);
        });
        posterImg.style.backgroundImage = `url('${albumImages[0]}')`;
        document.getElementById('album-model').style.display = 'block';
        backBtn.style.display = 'none';
        rightBtn.style.display = albumImages.length > 1 ? 'flex' : 'none';
    }

    function goBack() {
        next = -1;
        currentIndex -= 1;
        updateAlbum();
    }

    function goNext() {
        next = 1;
        currentIndex += 1;
        updateAlbum();
    }

    function updateAlbum() {
        backBtn.style.display = currentIndex === 0 ? 'none' : 'flex';
        rightBtn.style.display = currentIndex === albumImages.length - 1 ? 'none' : 'flex';
        posterImg.style.backgroundImage = `url('${albumImages[currentIndex]}')`;
        const animOut = next === -1 ? 'moveRightOff' : 'moveleftOff';
        const animIn = next === -1 ? 'moveRightIn' : 'moveLeftIn';
        posterImg.classList.add(animOut);
        setTimeout(() => {
            posterImg.classList.remove(animOut);
            posterImg.classList.add(animIn);
        }, 300);
        setTimeout(() => {
            posterImg.classList.remove(animIn);
        }, 600);
    }

    function loadEvent() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '/Controllers/GetAllEventHome.php', true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                document.getElementById('event-details').innerHTML = JSON.parse(xhr.responseText).html;
            }
        };
        xhr.send();
    }

    function loadAlbum() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '/Controllers/GetTopAlbums.php', true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                document.getElementById('gallery-content').innerHTML = JSON.parse(xhr.responseText).html;
            }
        };
        xhr.send();
    }
    window.onload = function() {
        loadEvent();
        loadAlbum();
    };
</script>